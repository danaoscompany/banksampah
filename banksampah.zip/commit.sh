git add .
git commit -m "Last commit"
git push -u origin main
